<?php
defined( 'ABSPATH' ) || exit;

if (! class_exists('Docent_Pro_Core_Functions')) {
    class Docent_Pro_Core_Functions{

        // public function example_function(){
        //     return 'Example Function';
        // }
        
        // public function register_api_hook(){
        //     // For update global options
        //     register_rest_route(
        //         'tutor', 
        //         '/v2/',
        //         array(
        //             'methods'  => 'GET', 
        //             'callback' => array( $this, 'get_global_option')
        //         ),

        //     );
        // }	

    }

    
}